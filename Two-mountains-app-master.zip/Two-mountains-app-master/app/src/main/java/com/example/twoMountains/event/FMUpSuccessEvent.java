package com.example.twoMountains.event;

public class FMUpSuccessEvent {
}
