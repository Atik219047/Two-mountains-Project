package com.example.twoMountains.util;

public class BooleanWrapper {
    public boolean value;

    public BooleanWrapper(boolean value) {
        this.value = value;
    }
}
